package com.arriendos.ms_clientes.controller;

import com.arriendos.ms_clientes.dto.DireccionRequestDTO;
import com.arriendos.ms_clientes.dto.DireccionResponseDTO;
import com.arriendos.ms_clientes.service.DireccionService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/direcciones")
public class DireccionController {

    private final DireccionService direccionService;

    public DireccionController(DireccionService direccionService) {
        this.direccionService = direccionService;
    }
    
    @GetMapping
    public ResponseEntity<List<DireccionResponseDTO>> listar() {
        return ResponseEntity.ok(direccionService.obtenerTodas());
    }
    @GetMapping("/{id}")
    public ResponseEntity<DireccionResponseDTO> obtenerPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(direccionService.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<DireccionResponseDTO> guardar(@Valid @RequestBody DireccionRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(direccionService.guardar(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<DireccionResponseDTO> actualizar(
            @PathVariable Integer id,
            @Valid @RequestBody DireccionRequestDTO dto) {

        return ResponseEntity.ok(direccionService.actualizar(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        direccionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }

}