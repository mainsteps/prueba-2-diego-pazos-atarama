package com.arriendos.ms_clientes.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class ClienteResponseDTO {

    private Integer id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private Integer edad;
    private Boolean activo;
    private LocalDate fechaRegistro;
    
}