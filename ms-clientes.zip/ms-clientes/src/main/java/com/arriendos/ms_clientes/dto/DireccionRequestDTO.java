package com.arriendos.ms_clientes.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class DireccionRequestDTO {

    @NotBlank(message = "La calle es obligatoria")
    @Size(min = 2, max = 120, message = "La calle debe tener entre 2 y 120 caracteres")
    private String calle;

    @NotNull(message = "El número es obligatorio")
    @Positive(message = "El número debe ser positivo")
    private Integer numero;

    @NotBlank(message = "La comuna es obligatoria")
    private String comuna;

    @NotBlank(message = "La ciudad es obligatoria")
    private String ciudad;

    @NotBlank(message = "El código postal es obligatorio")
    private String codigoPostal;

    @NotNull(message = "El estado principal es obligatorio")
    private Boolean principal;

    @NotNull(message = "La fecha de creación es obligatoria")
    @PastOrPresent(message = "La fecha no puede ser futura")
    private LocalDate fechaCreacion;

    @NotNull(message = "El clienteId es obligatorio")
    private Integer clienteId;

}