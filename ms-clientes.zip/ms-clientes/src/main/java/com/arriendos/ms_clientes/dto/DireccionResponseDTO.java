package com.arriendos.ms_clientes.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor
public class DireccionResponseDTO {

    private Integer id;
    private String calle;
    private Integer numero;
    private String comuna;
    private String ciudad;
    private String codigoPostal;
    private Boolean principal;
    private LocalDate fechaCreacion;
    private Integer clienteId;

}
