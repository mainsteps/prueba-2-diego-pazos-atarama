package com.arriendos.ms_clientes.mapper;

import com.arriendos.ms_clientes.dto.ClienteRequestDTO;
import com.arriendos.ms_clientes.dto.ClienteResponseDTO;
import com.arriendos.ms_clientes.model.Cliente;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public Cliente toEntity(ClienteRequestDTO dto) {
        Cliente cliente = new Cliente();

        cliente.setNombre(dto.getNombre());
        cliente.setApellido(dto.getApellido());
        cliente.setEmail(dto.getEmail());
        cliente.setTelefono(dto.getTelefono());
        cliente.setEdad(dto.getEdad());
        cliente.setActivo(dto.getActivo());
        cliente.setFechaRegistro(dto.getFechaRegistro());
        
        return cliente;
    }

    public ClienteResponseDTO toDTO(Cliente cliente) {
        return new ClienteResponseDTO(
                cliente.getId(),
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getEmail(),
                cliente.getTelefono(),
                cliente.getEdad(),
                cliente.getActivo(),
                cliente.getFechaRegistro()
        );
    }

}