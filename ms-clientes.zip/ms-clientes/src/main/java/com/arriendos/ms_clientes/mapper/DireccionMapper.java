package com.arriendos.ms_clientes.mapper;

import com.arriendos.ms_clientes.dto.DireccionRequestDTO;
import com.arriendos.ms_clientes.dto.DireccionResponseDTO;
import com.arriendos.ms_clientes.model.Cliente;
import com.arriendos.ms_clientes.model.Direccion;
import org.springframework.stereotype.Component;

@Component
public class DireccionMapper {

    public Direccion toEntity(DireccionRequestDTO dto, Cliente cliente) {
        Direccion direccion = new Direccion();

        direccion.setCalle(dto.getCalle());
        direccion.setNumero(dto.getNumero());
        direccion.setComuna(dto.getComuna());
        direccion.setCiudad(dto.getCiudad());
        direccion.setCodigoPostal(dto.getCodigoPostal());
        direccion.setPrincipal(dto.getPrincipal());
        direccion.setFechaCreacion(dto.getFechaCreacion());
        direccion.setCliente(cliente);

        return direccion;
    }

    public DireccionResponseDTO toDTO(Direccion direccion) {
        return new DireccionResponseDTO(
                direccion.getId(),
                direccion.getCalle(),
                direccion.getNumero(),
                direccion.getComuna(),
                direccion.getCiudad(),
                direccion.getCodigoPostal(),
                direccion.getPrincipal(),
                direccion.getFechaCreacion(),
                direccion.getCliente().getId()
        );
    }

}