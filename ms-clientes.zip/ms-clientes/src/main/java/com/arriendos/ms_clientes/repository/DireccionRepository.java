package com.arriendos.ms_clientes.repository;

import com.arriendos.ms_clientes.model.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DireccionRepository extends JpaRepository<Direccion, Integer> {
}