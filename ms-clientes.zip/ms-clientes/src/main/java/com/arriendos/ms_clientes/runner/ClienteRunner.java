package com.arriendos.ms_clientes.runner;

import com.arriendos.ms_clientes.model.Cliente;
import com.arriendos.ms_clientes.model.Direccion;
import com.arriendos.ms_clientes.repository.ClienteRepository;
import com.arriendos.ms_clientes.repository.DireccionRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
public class ClienteRunner implements CommandLineRunner {

    private final ClienteRepository clienteRepository;
    private final DireccionRepository direccionRepository;

    public ClienteRunner(ClienteRepository clienteRepository,
                         DireccionRepository direccionRepository) {
        this.clienteRepository = clienteRepository;
        this.direccionRepository = direccionRepository;
    }

    @Override
    public void run(String... args) {

        if (clienteRepository.count() == 0) {

            Cliente cliente1 = new Cliente();
            cliente1.setNombre("Diego");
            cliente1.setApellido("Pazos");
            cliente1.setEmail("diego@gmail.com");
            cliente1.setTelefono("94623089");
            cliente1.setEdad(24);
            cliente1.setActivo(true);
            cliente1.setFechaRegistro(LocalDate.now());

            Cliente cliente2 = new Cliente();
            cliente2.setNombre("Matias");
            cliente2.setApellido("Urrejola");
            cliente2.setEmail("matias@gmail.com");
            cliente2.setTelefono("324323433");
            cliente2.setEdad(27);
            cliente2.setActivo(true);
            cliente2.setFechaRegistro(LocalDate.now());

            Cliente cliente3 = new Cliente();
            cliente3.setNombre("Jorge");
            cliente3.setApellido("Zuniga");
            cliente3.setEmail("jorge@gmail.com");
            cliente3.setTelefono("546454353");
            cliente3.setEdad(40);
            cliente3.setActivo(false);
            cliente3.setFechaRegistro(LocalDate.now());

            clienteRepository.save(cliente1);
            clienteRepository.save(cliente2);
            clienteRepository.save(cliente3);

            Direccion direccion1 = new Direccion();
            direccion1.setCalle("Los Pinos");
            direccion1.setNumero(123);
            direccion1.setComuna("Providencia");
            direccion1.setCiudad("Santiago");
            direccion1.setCodigoPostal("7500000");
            direccion1.setPrincipal(true);
            direccion1.setFechaCreacion(LocalDate.now());
            direccion1.setCliente(cliente1);

            Direccion direccion2 = new Direccion();
            direccion2.setCalle("Las Flores");
            direccion2.setNumero(456);
            direccion2.setComuna("Maipu");
            direccion2.setCiudad("Santiago");
            direccion2.setCodigoPostal("7600000");
            direccion2.setPrincipal(false);
            direccion2.setFechaCreacion(LocalDate.now());
            direccion2.setCliente(cliente2);

            Direccion direccion3 = new Direccion();
            direccion3.setCalle("San Martin");
            direccion3.setNumero(789);
            direccion3.setComuna("La Florida");
            direccion3.setCiudad("Santiago");
            direccion3.setCodigoPostal("7700000");
            direccion3.setPrincipal(true);
            direccion3.setFechaCreacion(LocalDate.now());
            direccion3.setCliente(cliente3);

            direccionRepository.save(direccion1);
            direccionRepository.save(direccion2);
            direccionRepository.save(direccion3);

            System.out.println("Datos iniciales de clientes y direcciones cargados correctamente");
        }
    }
}