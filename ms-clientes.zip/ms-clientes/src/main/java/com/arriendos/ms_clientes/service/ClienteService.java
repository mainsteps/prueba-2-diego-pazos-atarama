package com.arriendos.ms_clientes.service;

import com.arriendos.ms_clientes.dto.ClienteRequestDTO;
import com.arriendos.ms_clientes.dto.ClienteResponseDTO;
import com.arriendos.ms_clientes.exception.ResourceNotFoundException;
import com.arriendos.ms_clientes.mapper.ClienteMapper;
import com.arriendos.ms_clientes.model.Cliente;
import com.arriendos.ms_clientes.repository.ClienteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteService {

    private static final Logger log = LoggerFactory.getLogger(ClienteService.class);
    private final ClienteRepository clienteRepository;
    private final ClienteMapper clienteMapper;
    public ClienteService(ClienteRepository clienteRepository, ClienteMapper clienteMapper) {
        this.clienteRepository = clienteRepository;
        this.clienteMapper = clienteMapper;
    }

    public List<ClienteResponseDTO> obtenerTodos() {
        log.info("Listando todos los clientes");

        return clienteRepository.findAll()
                .stream()
                .map(clienteMapper::toDTO)
                .collect(Collectors.toList());
    }

    public ClienteResponseDTO obtenerPorId(Integer id) {
        log.info("Buscando cliente por id {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));

        return clienteMapper.toDTO(cliente);
    }

    public ClienteResponseDTO guardar(ClienteRequestDTO dto) {
        try {
            log.info("Guardando cliente con email {}", dto.getEmail());

            Cliente cliente = clienteMapper.toEntity(dto);
            Cliente guardado = clienteRepository.save(cliente);
            return clienteMapper.toDTO(guardado);

        } catch (Exception e) {
            log.error("Error al guardar cliente: {}", e.getMessage());
            throw e;
        }
    }

    public ClienteResponseDTO actualizar(Integer id, ClienteRequestDTO dto) {
        log.info("Actualizando cliente con id {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));
        cliente.setNombre(dto.getNombre());
        cliente.setApellido(dto.getApellido());
        cliente.setEmail(dto.getEmail());
        cliente.setTelefono(dto.getTelefono());
        cliente.setEdad(dto.getEdad());
        cliente.setActivo(dto.getActivo());
        cliente.setFechaRegistro(dto.getFechaRegistro());

        Cliente actualizado = clienteRepository.save(cliente);

        return clienteMapper.toDTO(actualizado);
    }

    public void eliminar(Integer id) {
        log.info("Eliminando cliente con id {}", id);

        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));
        clienteRepository.delete(cliente);
    }

    public List<ClienteResponseDTO> buscarPorEmail(String email) {
        log.info("Buscando clientes por email que contenga {}", email);

        return clienteRepository.findByEmailContainingIgnoreCase(email)
                .stream()
                .map(clienteMapper::toDTO)
                .collect(Collectors.toList());
    }
    
}