package com.arriendos.ms_clientes.service;

import com.arriendos.ms_clientes.dto.DireccionRequestDTO;
import com.arriendos.ms_clientes.dto.DireccionResponseDTO;
import com.arriendos.ms_clientes.exception.ResourceNotFoundException;
import com.arriendos.ms_clientes.mapper.DireccionMapper;
import com.arriendos.ms_clientes.model.Cliente;
import com.arriendos.ms_clientes.model.Direccion;
import com.arriendos.ms_clientes.repository.ClienteRepository;
import com.arriendos.ms_clientes.repository.DireccionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DireccionService {

    private static final Logger log = LoggerFactory.getLogger(DireccionService.class);

    private final DireccionRepository direccionRepository;
    private final ClienteRepository clienteRepository;
    private final DireccionMapper direccionMapper;

    public DireccionService(DireccionRepository direccionRepository, ClienteRepository clienteRepository, DireccionMapper direccionMapper) {
        this.direccionRepository = direccionRepository;
        this.clienteRepository = clienteRepository;
        this.direccionMapper = direccionMapper;
    }

    public List<DireccionResponseDTO> obtenerTodas() {
        log.info("Listando todas las direcciones");

        return direccionRepository.findAll()
                .stream()
                .map(direccionMapper::toDTO)
                .collect(Collectors.toList());
    }

    public DireccionResponseDTO obtenerPorId(Integer id) {
        log.info("Buscando direccion por id {}", id);

        Direccion direccion = direccionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Direccion no encontrada con id " + id));

        return direccionMapper.toDTO(direccion);
    }

    public DireccionResponseDTO guardar(DireccionRequestDTO dto) {
        try {
            log.info("Guardando direccion para cliente id {}", dto.getClienteId());

            Cliente cliente = clienteRepository.findById(dto.getClienteId())
                    .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + dto.getClienteId()));
            Direccion direccion = direccionMapper.toEntity(dto, cliente);
            Direccion guardada = direccionRepository.save(direccion);

            return direccionMapper.toDTO(guardada);

        } catch (Exception e) {
            log.error("Error al guardar direccion: {}", e.getMessage());
            throw e;
        }
    }

    public DireccionResponseDTO actualizar(Integer id, DireccionRequestDTO dto) {
        log.info("Actualizando direccion con id {}", id);

        Direccion direccion = direccionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Direccion no encontrada con id " + id));
        Cliente cliente = clienteRepository.findById(dto.getClienteId())
                .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + dto.getClienteId()));

        direccion.setCalle(dto.getCalle());
        direccion.setNumero(dto.getNumero());
        direccion.setComuna(dto.getComuna());
        direccion.setCiudad(dto.getCiudad());
        direccion.setCodigoPostal(dto.getCodigoPostal());
        direccion.setPrincipal(dto.getPrincipal());
        direccion.setFechaCreacion(dto.getFechaCreacion());
        direccion.setCliente(cliente);
        Direccion actualizada = direccionRepository.save(direccion);

        return direccionMapper.toDTO(actualizada);
    }

    public void eliminar(Integer id) {
        log.info("Eliminando direccion con id {}", id);

        Direccion direccion = direccionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Direccion no encontrada con id " + id));
        direccionRepository.delete(direccion);
    }

}